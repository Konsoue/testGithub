window.onload = function(){
rolledpic("http://yapi.demo.qunar.com/mock/79252/academic/test");
var imgbox = document.getElementsByTagName('div')[1];
var lineb = document.getElementsByTagName('div')[2];
var whichButton = 0;
var ul = document.getElementsByTagName('ul')[0];
var aListName = [];
var picnum = 0; 
/* 定时轮播 */
var timer = null;
var liAll,spanAll;
function loading(url){
    var xhr = new XMLHttpRequest();
    xhr.open("GET",url,true);
    xhr.onload = function (){
        var imgs = JSON.parse(this.responseText);
        picnum = imgs.banners.length;
        var outputimg ='';
        for(var i = 0;i < picnum;i++)
        {
            aListName.push("list"+(1+i));
            outputimg = `<li class="`+aListName[i]+`">`+`<img src="${imgs.banners[i]}"></img></li>`;
            ul.innerHTML += outputimg;
            span = document.createElement('span');
            //span.style.backgroundColor = "#ccc";
            if(i == 0){ span.style.backgroundColor = "#008c8c";}
            else {span.style.backgroundColor = "#ccc";}
            lineb.appendChild(span);
        }
    }
    xhr.send();
}
function startTimer() {
    console.log("开启");
    timer = setInterval(function(){nextPic(liAll);},4000);
    } 
    startTimer();
function stopTimer(){
    console.log("关闭");
    clearInterval(timer);
    timer = null;
}
/* 封装按钮颜色函数 */
function buttonColor(spanAll){
    for(var i =0;i < picnum;i++){
        spanAll[i].style.backgroundColor = "#ccc";
    }
    if(spanAll[whichButton]!=undefined)spanAll[whichButton].style.backgroundColor = "#008c8c";
}
/* 上一张图片 */
function prePic(liAll){
    aListName.push(aListName[0]);
    aListName.shift();
    for(var i = 0;i < picnum;i++){
        liAll[i].setAttribute("class",aListName[i]);
    }
    whichButton--;
    if(whichButton < 0){whichButton += picnum;}
    buttonColor(spanAll);
}
/* 下一张图片 */
function nextPic(liAll){
    aListName.unshift(aListName[picnum-1]);
    aListName.pop();
    for(var i = 0;i < picnum;i++){
        liAll[i].setAttribute("class",aListName[i]);
    }
    whichButton = (whichButton + 1) % picnum;
    buttonColor(spanAll);
}
/* 切换图片函数封装 */
function whichPic(num,liAll){
            aListName = [];
    for(var i = 0;i<picnum;i++){ 
        aListName.push("list"+(i+1));
        console.log(aListName);
    }
    //aListName = ["list1","list2","list3","list4","list5","list6"];
    for(var i = 0;i < num;i++)
    {
        aListName.push(aListName[0]);
        aListName.shift();
    }
    for(var i = 0;i < picnum;i++){
        liAll[i].setAttribute("class",aListName[i]);
    }
    stopTimer();
    startTimer();
}

/* 头最大的函数 */
function rolledpic(url){
//拿个图片
new Promise(resolve=>{
    loading(url);
    resolve();
})
.then(value=>{console.log('a');})


setTimeout(function(){
 liAll = document.getElementsByTagName('li');
 spanAll = document.getElementsByTagName('span');
//console.log(spanAll);
buttonColor(spanAll);
/* 点击左右图片，切换事件绑定 */
imgbox.addEventListener("click",function(e){
    var event = e || window.event;
    console.log(liAll);
    if(event.target.parentNode.getAttribute("class") == ("list" + picnum)){
        prePic(liAll);
    }
    if(event.target.parentNode.getAttribute("class") == "list2"){
        nextPic(liAll);
    }
    stopTimer();
    startTimer();
},false);

imgbox.addEventListener("mouseover",function(){stopTimer();},false);
imgbox.addEventListener("mouseleave",function(){stopTimer(); startTimer();},false);//关闭多一点，狂点，mouseover出来可能没关
lineb.addEventListener("mouseover",function(){stopTimer();},false);
lineb.addEventListener("mouseleave",function(){stopTimer(); startTimer();},false);
/* 按钮划过事件绑定 */
for(var i = 0;i < picnum ;i++)
{   
    spanAll[i].num = i;
    spanAll[i].addEventListener("mouseover",function(e){
    var event = e || window.event;
    whichPic(event.target.num,liAll);
    whichButton = event.target.num;
    buttonColor(spanAll);
    },false);
}   
},1000);

}
};
